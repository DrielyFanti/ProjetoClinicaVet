<template>
  <div>
    <h1>Lista de Consultas</h1>
  </div>
</template>

<script>
export default {
  name: 'ConsultasView'
}
</script>